 -Vins Backend is a private server that supports all Fortnite versions!-
Credits to Lawin github link "https://github.com/Lawin0129" for alot of help.

 Features: most of lawins V1 features,
but with a little more and a few visual mods.


 How to use?
1) Install [NodeJS](https://nodejs.org/en/)
3) Run "start.bat", It should say "Started listening on port 3551"
4) Use something to redirect the fortnite servers to localhost:3551 (Which could be fiddler, ssl bypass that redirects servers, etc...)
